clientSecret = "d59f90b740604e9dbaf02b8e39e49ecf"
secret_key = "VsYB4ogop2"

def main():
    return [clientSecret,secret_key]

if __name__ == '__main__':
    main()